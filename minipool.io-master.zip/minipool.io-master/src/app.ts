window.onload = () => {

    const game = new MiniBillar.Game();
};
